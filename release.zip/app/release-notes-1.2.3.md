** Release notes 1.2.3 - 15. 2. 2024, 10:19:47

* 08.02.2024

* [milan jurkulak] : code improvements 

* 07.02.2024

* [milan jurkulak] : code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements 

* 09.01.2024

* [milan jurkulak] : number digits 
* [milan jurkulak] : code improvements 
* [milan jurkulak] : code improvements 
* [milan jurkulak] : background changes 

* 05.01.2024

* [milan jurkulak] : code improvements  
* [milan jurkulak] : webview fetcher  web scrapper webview  web scrapper webview 

* 27.12.2023

* [milan jurkulak] : build release fix 
* [milan jurkulak] : scrapper improvements 
* [milan jurkulak] : scrapper improvements  scrapper improvements  scrapper improvements  scrapper improvements 

* 26.12.2023

* [milan jurkulak] : config field fix / proguard fix 
* [milan jurkulak] : build improvements 

* 21.12.2023

* [milan jurkulak] : scrapper base  scrapper base 
* [milan jurkulak] : navigation improvements 

* 19.12.2023

* [milan jurkulak] : navigation improvements / need more improvements 

* 06.12.2023

* [milan jurkulak] : code improvements 
* [milan jurkulak] : code improvements 

* 05.12.2023

* [milan jurkulak] : scroll improvements 
* [milan jurkulak] : update fix 
* [milan jurkulak] : update fix 

* 04.12.2023

* [milan jurkulak] : update fix 
* [milan jurkulak] : update fix 
* [milan jurkulak] : app bump 
* [milan jurkulak] : merge remote-tracking branch 'origin/main' 
* [milan jurkulák] : delete .github/workflows/codeql.yml
* [milan jurkulak] : code improvements 
* [milan jurkulak] : code improvements  code improvements  code improvements  code improvements  code improvements 
* [milan jurkulak] : glide album art 
* [milan jurkulak] : web scrapper pre-implement  web scrapper pre-implement 

* 16.10.2023

* [milan jurkulak] : images glide 

* 12.10.2023

* [milan jurkulak] : libraries versions bump 
* [milan jurkulak] : theme dynamic & payments preimplementation 

* 06.10.2023

* [milan jurkulak] : image caching improvement 

* 05.10.2023

* [milan jurkulak] : minify temporary removal 
* [milan jurkulak] : code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements  code improvements 

* 30.09.2023

* [milan jurkulak] : merge remote-tracking branch 'origin/main' 
* [milan jurkulak] : code cleanup 
* [milan jurkulak] : image loader improvements 

* 29.09.2023

* [milan jurkulák] : codeql.yml
* [milan jurkulak] : remembers 

* 27.09.2023

* [milan jurkulak] : test component 
* [milan jurkulak] : app updater 
* [milan jurkulak] : html scrapper 
* [milan jurkulak] : design improvement 

* 21.08.2023

* [milan jurkulak] : sync improvement 

* 20.08.2023

* [milan jurkulak] : play next on error preimplementation 
* [milan jurkulak] : sync improvement 
* [milan jurkulak] : network check improvement 
* [milan jurkulak] : mobile apps fix 
* [milan jurkulak] : app updater preimplement  app updater  app updater  app updater 
* [milan jurkulak] : messages, resources 
* [milan jurkulak] : code coments 

* 19.08.2023

* [milan jurkulak] : mediaitem uri fix 
* [milan jurkulak] : mediaitem uri fix 
* [milan jurkulak] : design improvements  design improvements  design improvements 
* [milan jurkulak] : media player improvements 
* [milan jurkulak] : nav controller fix 
* [milan jurkulak] : lifecycle fix 

* 18.08.2023

* [milan jurkulak] : caching cursor fixes 

* 11.08.2023

* [milan jurkulak] : code improvements 
* [milan jurkulak] : code improvements 
* [milan jurkulak] : notification importance change 
* [milan jurkulak] : player improvements  player improvements 

* 10.08.2023

* [milan jurkulak] : gridviews preimplementation  
* [milan jurkulak] : media session  media session 
* [milan jurkulak] : audio focus 
* [milan jurkulak] : graphic resources & widget prepare 
* [milan jurkulak] : mediaplayer widget preimplementation 
* [milan jurkulak] : mediaplayer lifecycle / performance 
* [milan jurkulak] : media state fixes 
* [milan jurkulak] : audio preview fixes 

* 09.08.2023

* [milan jurkulak] : playernotificationmanager preimplementation (mobile) 
* [milan jurkulak] : code cleanup 
* [milan jurkulak] : sync improvements 
* [milan jurkulak] : code improvements 
* [milan jurkulak] : design fixes 
* [milan jurkulak] : performance improvements  
* [milan jurkulak] : sanwitch lib for removing bpt 

* 08.08.2023

* [milan jurkulak] : audio player preview dailymotion 
* [milan jurkulak] : config changes preparation 
* [milan jurkulak] : exoplayer transparency 
* [milan jurkulak] : padding fix main screen 
* [milan jurkulak] : download video for audio files, preimplementation 
* [milan jurkulak] : design improvements  design improvements  design improvements  design improvements  design improvements  design improvements 

* 07.08.2023

* [milan jurkulak] : navigation padding 
* [milan jurkulak] : gallery double tap 
* [milan jurkulak] : gallery selection fix 
* [milan jurkulak] : code cleanup & improvements 
* [milan jurkulak] : page improvements 
* [milan jurkulak] : focus fixes  
* [milan jurkulak] : design fixes  design fixes 
* [milan jurkulak] : carousel reimplementation 
* [milan jurkulak] : carousel reimplementation 
* [milan jurkulak] : activity lifecycle improvements 
* [milan jurkulak] : image cache improvements 
* [milan jurkulak] : manifest fixes 
* [milan jurkulak] : cursor improvements 
* [milan jurkulak] : anr fixes 

* 06.08.2023

* [milan jurkulak] : code fixes 
* [milan jurkulak] : coil improvements 
* [milan jurkulak] : caching album art data 
* [milan jurkulak] : placeholder improvement 
* [milan jurkulak] : webview fixes 
* [milan jurkulak] : album art downloader cover art improvement 
* [milan jurkulak] : album art downloader cover art 
* [milan jurkulak] : gallery custom overlay support 
* [milan jurkulak] : web client user agent 
* [milan jurkulak] : carousel fixes 
* [milan jurkulak] : swipe gestures for big carousel & gallery 
* [milan jurkulak] : swipe gestures for big carousel & gallery 
* [milan jurkulak] : code cleanup 
* [milan jurkulak] : icon change 
* [milan jurkulak] : item info improvement 
* [milan jurkulak] : item info improvement 
* [milan jurkulak] : code clean 
* [milan jurkulak] : storage permissions fix 
* [milan jurkulak] : detail improvements  detail improvements  detail improvements  detail improvements  detail improvements  detail improvements  detail improvements  detail improvements  detail improvements 

* 04.08.2023

* [milan jurkulak] : library update post fixes 
* [milan jurkulak] : agp upgrade  agp upgrade 

* 03.08.2023

* [milan jurkulak] : oauth preimplementation 
* [milan jurkulak] : library update 

* 02.08.2023

* [milan jurkulak] : detail screen improvements  detail screen improvements  detail screen improvements 
* [milan jurkulak] : player improvements 
* [milan jurkulak] : settings preimlplementation 
* [milan jurkulak] : album art for coil 
* [milan jurkulak] : mobile navigation modal 

* 01.08.2023

* [milan jurkulak] : player improvements & detail improvements 
* [milan jurkulak] : code improvements  code improvements  code improvements 
* [milan jurkulak] : better navigation prepare  better navigation prepare 
* [milan jurkulak] : main page improvements 
* [milan jurkulak] : portrait / landscape mode 

* 23.07.2023

* [milan jurkulak] : code improvements for preview 
* [milan jurkulak] : repos refactor 

* 22.07.2023

* [milan jurkulak] : data fixes 
* [milan jurkulak] : design improvements 
* [milan jurkulak] : iptv categories 
* [milan jurkulak] : iptv 
* [milan jurkulak] : media player controls  media player controls 

* 21.07.2023

* [milan jurkulak] : pages improvement 
* [milan jurkulak] : lottie support 

* 18.07.2023

* [milan jurkulak] : code move / anr reporting 
* [milan jurkulak] : libs update 
* [milan jurkulak] : new screenshots 
* [milan jurkulak] : libs ver. upgrade 
* [milan jurkulak] : media player controls 
* [milan jurkulak] : xml layout component 
* [milan jurkulak] : anr spy 
* [milan jurkulak] : photo improvements 

* 12.07.2023

* [milan jurkulak] : photo improvements 
* [milan jurkulak] : photo detail fix 
* [milan jurkulak] : launcher add 
* [milan jurkulak] : performance fix 
* [milan jurkulak] : app manager fix / removal of itself from list 
* [milan jurkulak] : photo item tablet fix 
* [milan jurkulak] : card text focus background 
* [milan jurkulak] : fading background 
* [milan jurkulak] : readme update 
* [milan jurkulak] : temporary dokka disablement & code cleanup 
* [milan jurkulak] : items improve 
* [milan jurkulak] : library pre-implementation 
* [milan jurkulak] : tablet photos cursor fix 
* [milan jurkulak] : tablet screen padding fix 
* [milan jurkulak] : tablet background fix 
* [milan jurkulak] : cursor sort order  cursor sort order 
* [milan jurkulak] : carousel finalization 
* [milan jurkulak] : featured items #1 
* [milan jurkulak] : tv pager fix #1 
* [milan jurkulak] : performance improvements 

* 11.07.2023

* [milan jurkulak] : pager animation 
* [milan jurkulak] : image load improvement 
* [milan jurkulak] : cursor row scroll improvement 
* [milan jurkulak] : cursor row scroll improvement 
* [milan jurkulak] : cursor improvement  cursor improvement 
* [milan jurkulak] : permissions pre-implementation  permissions fix 

* 10.07.2023

* [milan jurkulak] : code cleanup 
* [milan jurkulak] : lifecycle preimplementation 
* [milan jurkulak] : net state improvements 
* [milan jurkulak] : gui improvements 
* [milan jurkulak] : cursor rows improvement 
* [milan jurkulak] : columns fix for older devices 
* [milan jurkulak] : one line text in cards 
* [milan jurkulak] : recompose fixes  recompose fixes #2  recompose fixes #4 
* [milan jurkulak] : recompose debugging 
* [milan jurkulak] : custom adapter and custom rows  custom adapter and custom rows  coil more sources  scroll horizontal lists  scroll horizontal lists  scroll horizontal lists  scroll horizontal lists  details  details  details 

* 07.07.2023

* [milan jurkulak] : themes preimplementation 
* [milan jurkulak] : paging preimplementation 
* [milan jurkulak] : design improvements 

* 02.07.2023

* [milan jurkulak] : design improvements 
* [milan jurkulak] : design improvements 
* [milan jurkulak] : responsive design improvements 
* [milan jurkulak] : contentpadding badge fix 
* [milan jurkulak] : touch event fix 
* [milan jurkulak] : card aspect fix 
* [milan jurkulak] : page focus 
* [milan jurkulak] : focusing fix, final 
* [milan jurkulak] : carousel fix 
* [milan jurkulak] : focusing fix 

* 01.07.2023

* [milan jurkulak] : gui improvements 
* [milan jurkulak] : navigation code cleanup 
* [milan jurkulak] : ui improvements 

* 30.06.2023

* [milan jurkulak] : touch handling  
* [milan jurkulak] : navigation improvements 
* [milan jurkulak] : ui improvements ui improvements ui improvements #1 
* [milan jurkulak] : code cleanup 
* [milan jurkulak] : pager preimplementation 
* [milan jurkulak] : merge branch 'page1' into main

* 29.06.2023

* [milan jurkulak] : ui improvements 
* [milan jurkulak] : code improvements 
* [milan jurkulak] : code improvements 

* 28.06.2023

* [milan jurkulak] : caching fix 
* [milan jurkulak] : pager implementation 
* [milan jurkulak] : merge branch 'old_working' into main
* [milan jurkulak] : previews improvement/components 

* 27.06.2023

* [milan jurkulak] : screens improvement 
* [milan jurkulak] : network state fixes 
* [milan jurkulak] : design fixes tabs  design fixes tabs 
* [milan jurkulak] : design fixes header 
* [milan jurkulak] : pager preimplementation 

* 26.06.2023

* [milan jurkulak] : repo clean 
* [milan jurkulak] : ignore update 
* [milan jurkulak] : ignore update 
* [milan jurkulak] : documentation index  ignore update 
* [milan jurkulak] : carousel touchable implementation 
* [milan jurkulak] : code clean / icons for screens  media player fix  splash screen menu removal  delete .gradle directory delete .idea directory create security.md design improvements  git ignore items update  git ignore items update 
* [milan] : create security.md
* [milan] : delete .idea directory
* [milan] : delete .gradle directory
* [milan jurkulak] : splash screen menu removal 
* [milan jurkulak] : media player fix 

* 25.06.2023

* [milan jurkulak] : code clean / icons for screens 
* [milan jurkulak] : initial commit 
